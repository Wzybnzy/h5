var myswiper = new Swiper(".big", {
    on: {
        slideChange: function() {
            var idx = myswiper.activeIndex;
            $('.nav ul>li').removeClass();
            $('.nav ul>li').eq(idx).addClass('active');
        }
    }
});


$('.nav ul').on('click', "li", function() {
    var index = $(this).index();
    myswiper.slideTo(index);
})


$.ajax({
    url: "data/data.json",
    success: function(rs) {
        var str = '';
        for (var k in rs) {
            $.each(rs[k], function(i, item) {
                str += `<dl>
                        <dt><img src="${item.src}" alt=""></dt>
                        <dd>
                            <div>
                                <h2>${item.name}</h2>
                                <p class="p">${item.week}</p>
                                <h3><span>${item.num}</span><span>${item.sore}</span></h3>
                            </div>
                            <div class="buy">
                                <h6><b>￥${item.money}</b>起<i class="iconfont icon-chevron-thin-right"></i></h6>
                                <p>￥${item.oldmoney}</p>
                            </div>
                        </dd>
                    </dl>`;
            })
            $('.list').append(str);
        }
    }
})